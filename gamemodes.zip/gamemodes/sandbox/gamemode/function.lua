--- Copyright © 2026, YourLocalCappy, all rights deserved ---

-- it's not the right thing to do
-- but I wanted this damn thing working

function GM:CreateDefaultPanels()
  ColorPrint(0, 255, 255, 255, "HALF-LIFE 2 SANDBOX: RESSURECTED")
end

local draw = MoveHelper()

hook.add( "Think", "TestHook", function()
  draw:Con_NPrintf(0, "Half-Life 2 Sandbox Ressurected")
  draw:Con_NPrintf(1, "by YourLocalCappy")
end)