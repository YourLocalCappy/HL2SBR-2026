--- Copyright � 2026, YourLocalCappy, all rights deserved ---

include( "shared.lua" )
include( "in_main.lua" )
include( "function.lua" )
include( "scripted_controls/buildmenu.lua" )

local draw = MoveHelper()

hook.add( "Think", "TestHook", function()
  draw:Con_NPrintf(0, "Half-Life 2 Sandbox Ressurected")
  draw:Con_NPrintf(1, "by YourLocalCappy")
end)

hook.add( "Initialize", "TestHookTwo", function()
  draw:Con_NPrintf(0, "Half-Life 2 Sandbox Ressurected")
  draw:Con_NPrintf(1, "by YourLocalCappy")
end)

function GM:ActivateClientUI()
end

function GM:AdjustEngineViewport( x, y, width, height )
end

function GM:CanShowSpeakerLabels()
end

function GM:CreateDefaultPanels()
end

function GM:DrawHeadLabels( pPlayer )
end

function GM:GetPlayerTextColor( entindex, r, g, b )
end

function GM:HideClientUI()
end

function GM:HudElementShouldDraw( pElementName )
end

function GM:HudViewportPaint()
end

function GM:KeyInput( down, keynum, pszCurrentBinding )
end

function GM:LevelInitPreEntity()
end

function GM:LevelInitPostEntity()
end

function GM:OnScreenSizeChanged( iOldWide, iOldTall )
end

function GM:PlayerUpdateFlashlight( pHL2MPPlayer, position, vecForward, vecRight, vecUp, nDistance )
end

function GM:ShouldDrawCrosshair()
end

function GM:ShouldDrawDetailObjects()
end

function GM:ShouldDrawEntity( pEnt )
end

function GM:ShouldDrawFog()
end

function GM:ShouldDrawLocalPlayer()
end

function GM:ShouldDrawParticles()
end

function GM:ShouldDrawViewModel()
end
