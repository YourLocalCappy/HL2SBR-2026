--- Copyright © 2026, YourLocalCappy, all rights deserved ---

require( "concommand" )

local function IN_BuildDown( pPlayer, pCmd, args )
	if ( gBuildMenuInterface ) then
		gBuildMenuInterface:ShowPanel( true )
	end
end

concommand.Create( "+buildmenu", IN_BuildDown, nil )

local function IN_BuildUp( pPlayer, pCmd, args )
	if ( gBuildMenuInterface ) then
		gBuildMenuInterface:ShowPanel( false )
	end
end

concommand.Create( "-buildmenu", IN_BuildUp, nil )
