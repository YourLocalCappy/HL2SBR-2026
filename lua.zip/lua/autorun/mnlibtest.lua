--- Copyright © 2026, YourLocalCappy, all rights deserved ---

require("mnlib")

if SERVER then return end
mnlib.CreateButton("MNLIB2", "say yeah2")
mnlib.CreateTab("Test2")
mnlib.CreateButtonInTab("Test2", "Another Button2", "say working")