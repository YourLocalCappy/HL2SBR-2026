--- Copyright © 2026, YourLocalCappy, all rights deserved ---

if SERVER then
hint.Add("Use+Walk to move props closer and further with physgun!")
end