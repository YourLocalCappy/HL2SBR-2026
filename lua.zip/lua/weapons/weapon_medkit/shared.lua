--- Copyright © 2026, YourLocalCappy, all rights deserved ---

SWEP.__base = "weapon_tabledbase_scriptedweapon"

SWEP.Table = {
    PrintName = "MEDKIT",
    ViewModel = "models/weapons/c_medkit.mdl",
    WorldModel = "",
    AnimPrefix = "python",
    Slot = 5,
    SlotPos = 0,
    ClipSize    = -1,
    DefaultClip = -1,
    Ammo        = "None",
    Clip2Size    = -1,
    DefaultClip2 = -1,
    Ammo2        = "None",
    ShowHint       = 0,
    AutoSwitchTo   = 1,
    AutoSwitchFrom = 1,
    RightHanded    = 1,
    AllowFlipping  = 1,
    Melee          = 1,
    Weight         = 5,
    Damage         = 0
}

SWEP.SoundData				=
{
	empty       = "Weapon_Pistol.Empty",
	single_shot = "items/smallmedkit1.wav"
}

SWEP.m_acttable = {
	{ ACT.MP_STAND_IDLE, ACT.HL2MP_IDLE_PISTOL, false },
	{ ACT.MP_CROUCH_IDLE, ACT.HL2MP_IDLE_CROUCH_PISTOL, false },

	{ ACT.MP_RUN, ACT.HL2MP_RUN_PISTOL, false },
	{ ACT.MP_CROUCHWALK, ACT.HL2MP_WALK_CROUCH_PISTOL, false },

	{ ACT.MP_ATTACK_STAND_PRIMARYFIRE, ACT.HL2MP_GESTURE_RANGE_ATTACK_PISTOL, false },
	{ ACT.MP_ATTACK_CROUCH_PRIMARYFIRE, ACT.HL2MP_GESTURE_RANGE_ATTACK_PISTOL, false },

	{ ACT.MP_RELOAD_STAND, ACT.HL2MP_GESTURE_RELOAD_PISTOL, false },
	{ ACT.MP_RELOAD_CROUCH, ACT.HL2MP_GESTURE_RELOAD_PISTOL, false },

	{ ACT.MP_JUMP, ACT.HL2MP_JUMP_PISTOL, false },
}

function SWEP:Initialize()
	self.m_bReloadsSingly   = true
	self.m_bFiresUnderwater = true
end

function SWEP:PrimaryAttack()
	local pPlayer = self:GetOwner()

	local health = pPlayer:GetHealth()
	local maxhp = pPlayer:GetMaxHealth()

	self:WeaponSound(1)
	self:SendWeaponAnim(ACT.VM_PRIMARYATTACK)

	self.m_flNextPrimaryAttack = gpGlobals.curtime() + 1
	self.m_flNextSecondaryAttack = gpGlobals.curtime() + 0.75

	if health < maxhp then
		pPlayer:SetHealth(math.min(health + 5, maxhp))
	end
end

function SWEP:SecondaryAttack()
end

function SWEP:Reload()
end

function SWEP:GetDrawActivity()
	return ACT.VM_DRAW
end

function SWEP:Precache() 
end

function SWEP:Think() 
end

function SWEP:CanHolster() 
end

function SWEP:Deploy() 
end

function SWEP:Holster() 
end

function SWEP:ItemPostFrame()
end

function SWEP:ItemBusyFrame() 
end

function SWEP:DoImpactEffect() 
end