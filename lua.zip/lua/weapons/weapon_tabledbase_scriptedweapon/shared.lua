--- Copyright © 2026, YourLocalCappy, all rights deserved ---

SWEP.Table = {
PrintName = "Tabled Base Scripted Weapon",
ViewModel = "models/weapons/c_357.mdl",
WorldModel = "models/weapons/w_357.mdl",
AnimPrefix = "python",
Slot = 1,
SlotPos = 1,
ClipSize    = 20,
DefaultClip = 20,
Ammo        = "357",
Clip2Size    = -1,
DefaultClip2 = -1,
Ammo2        = "None",
ShowHint			= 0,
AutoSwitchTo			= 1,
AutoSwitchFrom			= 1,
RightHanded    = 0,
AllowFlipping   = 1,
Melee  = 0,
Weight  = 7,
Damage = 75
}

SWEP.item_flags				= 0 -- idc

SWEP.SoundData				=
{
empty					= "Weapon_Pistol.Empty",
single_shot				= "Weapon_357.Single"
}

SWEP.m_acttable = {
{ ACT.MP_STAND_IDLE, ACT.HL2MP_IDLE_REVOLVER, false },
{ ACT.MP_CROUCH_IDLE, ACT.HL2MP_IDLE_CROUCH_REVOLVER, false },

{ ACT.MP_RUN, ACT.HL2MP_RUN_REVOLVER, false },
{ ACT.MP_CROUCHWALK, ACT.HL2MP_WALK_CROUCH_REVOLVER, false },

{ ACT.MP_ATTACK_STAND_PRIMARYFIRE, ACT.HL2MP_GESTURE_RANGE_ATTACK_REVOLVER, false },
{ ACT.MP_ATTACK_CROUCH_PRIMARYFIRE, ACT.HL2MP_GESTURE_RANGE_ATTACK_REVOLVER, false },

{ ACT.MP_RELOAD_STAND, ACT.HL2MP_GESTURE_RELOAD_REVOLVER, false },
{ ACT.MP_RELOAD_CROUCH, ACT.HL2MP_GESTURE_RELOAD_REVOLVER, false },

{ ACT.MP_JUMP, ACT.HL2MP_JUMP_REVOLVER, false },

}

function SWEP:Initialize()
self.m_bReloadsSingly	= false
self.m_bFiresUnderwater	= false
end

function SWEP:Precache()
end

function SWEP:PrimaryAttack()
local pPlayer = self:GetOwner()

if ( ToBaseEntity( pPlayer ) == NULL ) then
return
end

if ( self.m_iClip1 <= 0 ) then
if ( not self.m_bFireOnEmpty ) then
self:Reload()
else
self:WeaponSound( 0 )
self.m_flNextPrimaryAttack = 0.15
end

return

end

self:WeaponSound( 1 )
pPlayer:DoMuzzleFlash()

self:SendWeaponAnim( ACT.VM_PRIMARYATTACK )
pPlayer:SetAnimation( PLAYER_ANIM.ATTACK )
ToHL2MPPlayer(pPlayer):DoAnimationEvent( PLAYERANIMEVENT.FIRE_GUN_PRIMARY )

self.m_flNextPrimaryAttack = gpGlobals.curtime() + 0.75
self.m_flNextSecondaryAttack = gpGlobals.curtime() + 0.75

self.m_iClip1 = self.m_iClip1 - 1

local vecSrc		= pPlayer:Weapon_ShootPosition()
local vecAiming		= pPlayer:GetAutoaimVector( 0.08715574274766 )

local info = {
m_iShots = 1,
m_vecSrc = vecSrc,
m_vecDirShooting = vecAiming,
m_vecSpread = vec3_origin,
m_flDistance = MAX_TRACE_LENGTH,
m_iAmmoType = self.m_iPrimaryAmmoType
}

info.m_pAttacker = pPlayer

pPlayer:FireBullets( info )

local angles = pPlayer:GetLocalAngles()

angles.x = angles.x + random.RandomInt( -1, 1 )
angles.y = angles.y + random.RandomInt( -1, 1 )
angles.z = 0

if not _CLIENT then
pPlayer:SnapEyeAngles( angles )
end

pPlayer:ViewPunch( QAngle( -8, random.RandomFloat( -2, 2 ), 0 ) )

if ( self.m_iClip1 == 0 and pPlayer:GetAmmoCount( self.m_iPrimaryAmmoType ) <= 0 ) then
pPlayer:SetSuitUpdate( "!HEV_AMO0", 0, 0 )
end

end

function SWEP:SecondaryAttack()
end

function SWEP:Reload()
local fRet = self:DefaultReload(
self:GetMaxClip1(),
self:GetMaxClip2(),
ACT.VM_RELOAD
)

if fRet then    
	ToHL2MPPlayer(self:GetOwner()):DoAnimationEvent( PLAYERANIMEVENT.RELOAD )    
end    

return fRet

end

function SWEP:Think()
end

function SWEP:CanHolster()
end

function SWEP:Deploy()
end

function SWEP:GetDrawActivity()
return ACT.VM_DRAW
end

function SWEP:Holster()
end

function SWEP:ItemPostFrame()
end

function SWEP:ItemBusyFrame()
end

function SWEP:DoImpactEffect()
end