include("shared.lua")

function SWEP:CapabilitiesGet() end
