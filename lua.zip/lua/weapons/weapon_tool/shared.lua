--- Copyright © 2026, YourLocalCappy, all rights deserved ---

SWEP.__base = "weapon_tabledbase_scriptedweapon"

local NTools = {}

local SCALES = {
    down   = "0.1 0.1 0.1",
    down2  = "0.5 0.5 0.5",
    normal = "1 1 1",
    up     = "2 2 2",
    up2    = "4 4 4",
    up3    = "10 10 10",
    up4    = "20 20 20"
}

function NTools.Resize(size)
    local scale = SCALES[size]
    if not scale then return end

    engine.ServerCommand(
        "ent_fire !picker SetModelScale " .. scale .. "\n"
    )
end

local UTIL = util or {}

local SERVER = not _CLIENT

local CLIENT = _CLIENT

local draw = MoveHelper()

local function DoTrace(pPlayer, dist)
local start = pPlayer:EyePosition()

local f = Vector()
pPlayer:EyeVectors(f, nil, nil)

local finish = start + f * (dist or 8192)

local tr = trace_t()
UTIL.TraceLine(
start,
finish,
_E.MASK and _E.MASK.SHOT or 0,
pPlayer,
0,
tr
)

return tr
end

function table.Count(t)
local c = 0
for _ in pairs(t) do
c = c + 1
end
return c
end

SWEP.Table = {
PrintName = "TOOL GUN",
ViewModel = "models/weapons/c_toolgun.mdl",
WorldModel = "models/weapons/w_toolgun.mdl",
AnimPrefix = "smg2",
Slot = 1,
SlotPos = 3,
ClipSize = -1,
DefaultClip = -1,
Ammo = "None",
Clip2Size = -1,
DefaultClip2 = -1,
Ammo2 = "None",
ShowHint = 0,
AutoSwitchTo = 1,
AutoSwitchFrom = 1,
RightHanded = 1,
AllowFlipping = 1,
Melee = 1,
Weight = 4,
Damage = 0
}

SWEP.SoundData = {
empty = "Airboat.FireGunRevDown",
single_shot = "Airboat.FireGunRevDown",
}

SWEP.m_acttable = {
{ ACT.MP_STAND_IDLE, ACT.HL2MP_IDLE_REVOLVER, false },
{ ACT.MP_CROUCH_IDLE, ACT.HL2MP_IDLE_CROUCH_REVOLVER, false },
{ ACT.MP_RUN, ACT.HL2MP_RUN_REVOLVER, false },
{ ACT.MP_CROUCHWALK, ACT.HL2MP_WALK_CROUCH_REVOLVER, false },
{ ACT.MP_ATTACK_STAND_PRIMARYFIRE, ACT.HL2MP_GESTURE_RANGE_ATTACK_REVOLVER, false },
{ ACT.MP_ATTACK_CROUCH_PRIMARYFIRE, ACT.HL2MP_GESTURE_RANGE_ATTACK_REVOLVER, false },
{ ACT.MP_RELOAD_STAND, ACT.HL2MP_GESTURE_RELOAD_REVOLVER, false },
{ ACT.MP_RELOAD_CROUCH, ACT.HL2MP_GESTURE_RELOAD_REVOLVER, false },
{ ACT.MP_JUMP, ACT.HL2MP_JUMP_REVOLVER, false },
}

SWEP.Tools = {}

function SWEP:RegisterTool(name, tbl)
self.Tools[name] = tbl
end

function SWEP:GetActiveTool()
return self.Tools[self.CurrentTool or ""]
end

function SWEP:Initialize()
self.m_bReloadsSingly = false
self.m_bFiresUnderwater = true
self.CurrentTool = nil
self:LoadTools()
end

function SWEP:PrimaryAttack()
local pPlayer = self:GetOwner()
if not pPlayer then return end

self.m_flNextPrimaryAttack = gpGlobals.curtime() + 0.15

self:SendWeaponAnim(ACT.VM_PRIMARYATTACK)
self:WeaponSound(1)

if SERVER then
engine.ServerCommand("ent_create env_spark; ent_fire env_spark SparkOnce; wait; wait; wait; ent_fire env_spark kill\n")
end

local tr = DoTrace(pPlayer, 56755)

local tool = self.Tools[self.CurrentTool]
if tool and tool.PrimaryAttack then
tool:PrimaryAttack(self, pPlayer, tr)
end
end

function SWEP:CycleTool()
local keys = {}
for k in pairs(self.Tools) do
table.insert(keys, k)
end
table.sort(keys)

if #keys == 0 then return end

local idx = 0
for i, v in ipairs(keys) do
if v == self.CurrentTool then
idx = i
break
end
end

idx = idx + 1
if idx > #keys then idx = 1 end
self.CurrentTool = keys[idx]
end

function SWEP:SecondaryAttack()
local pPlayer = self:GetOwner()
if not pPlayer then return end
if not next(self.Tools) then return end

local tr = DoTrace(pPlayer, 56755)

local tool = self.Tools[self.CurrentTool]
if tool and tool.SecondaryAttack then
tool:SecondaryAttack(self, pPlayer, tr)
end

self:CycleTool()
self.m_flNextSecondaryAttack = gpGlobals.curtime() + 0.5
end

function SWEP:Reload()
  self.Table.RightHanded = 1
end

function SWEP:LoadTools()
local draw = MoveHelper()
local MELON_MODEL = "models/props_junk/watermelon01.mdl"

self.SetAllowPrecache(true)
self.PrecacheModel(MELON_MODEL)

local function NewTool(id, name, desc)
return { ID = id, Name = name, Description = desc }
end

do
local TOOL = NewTool("fusion", "Fusion Link", "Bind two entities together")
TOOL.Buffer = nil

function TOOL:PrimaryAttack(swep, pPlayer, tr)  
  local ent = tr.m_pEnt  
  if not ent or ent == NULL or ent:IsPlayer() then return end  

  if not self.Buffer then  
    self.Buffer = ent  
    return  
  end  

  if ent == self.Buffer then return end  

  local a, b = self.Buffer, ent  
  local na, nb = "fx_" .. a:entindex(), "fx_" .. b:entindex()  

  a:KeyValue("targetname", na)  
  b:KeyValue("targetname", nb)  

  local c = CreateEntityByName("phys_constraint")  
  if c ~= NULL then  
    c:KeyValue("attach1", na)  
    c:KeyValue("attach2", nb)  
    c:Spawn()  
    c:Activate()  
  end  

  self.Buffer = nil  
end  

self:RegisterTool(TOOL.Name, TOOL)

end

do
local TOOL = NewTool("resize", "Resizer", "Resize entities")

TOOL.Sizes = {
    "down",
    "down2",
    "normal",
    "up",
    "up2",
    "up3"
}

TOOL.Index = {}

local function IsValidEnt(ent)
    return ent and ent ~= NULL and not ent:IsPlayer()
end

function TOOL:PrimaryAttack(swep, pPlayer, tr)
    if CLIENT then return end
    if tr:DidHitWorld() then return end
    if not tr.m_pEnt or tr.m_pEnt == NULL then return end

    local id = tr.m_pEnt:entindex()

    local i = (self.Index[id] or 0) + 1
    if i > #self.Sizes then i = 1 end
    self.Index[id] = i

    local size = self.Sizes[i]

    NTools.Resize(size)

    draw:Con_NPrintf(2, "[Resizer] Scale: " .. size)
end

function TOOL:SecondaryAttack(swep, pPlayer, tr)
end

self:RegisterTool(TOOL.Name, TOOL)
end

do
local TOOL = NewTool("chroma", "Chroma Painter", "Paint entities")
TOOL.Index = {}

TOOL.Palette = {
Color(255,0,0),
Color(0,255,0),
Color(0,0,255),
Color(255,255,0),
Color(0,255,255),
Color(255,0,255),
Color(0,200,255),
Color(0,0,0),
Color(255,255,255)
}

function TOOL:PrimaryAttack(swep, pPlayer, tr)
local ent = tr.m_pEnt
if not ent or ent == NULL or ent:IsPlayer() then return end

local id = ent:entindex()
local i = (self.Index[id] or 0) + 1
if i > #self.Palette then i = 1 end
self.Index[id] = i

local c = self.Palette[i]
ent:SetRenderColor(c:r(), c:g(), c:b())
draw:Con_NPrintf(2, "[Painter] Applied color")
end

function TOOL:SecondaryAttack(swep, pPlayer, tr)
end

self:RegisterTool(TOOL.Name, TOOL)
end

do
local TOOL = NewTool("duplic", "Duplic", "Duplicates entities")
TOOL.Dups = nil

local function IsValidEnt(ent)
return ent and ent ~= NULL and not ent:IsPlayer()
end

function TOOL:PrimaryAttack(swep, pPlayer, tr)
if not tr then return end

if tr:DidHitWorld() then
if not self.Dups then
draw:Con_NPrintf(2, "[Duplic] Nothing copied")
return
end

local data = self.Dups
local spawnPos = tr.endpos + Vector(0, 0, 8)

local ent = CreateEntityByName(data.class or "prop_physics")
if not ent or ent == NULL then
draw:Con_NPrintf(2, "[Duplic] Failed to create entity")
return
end

if data.model and ent.SetModel then
ent:SetModel(data.model)
end

ent:SetAbsOrigin(spawnPos)
ent:SetAbsAngles(data.angles or QAngle(0,0,0))

ent:Spawn()
ent:Activate()

if data.mass and ent:VPhysicsGetObject() ~= NULL then
local phys = ent:VPhysicsGetObject()
phys:SetMass(data.mass)
phys:Wake()
end

draw:Con_NPrintf(2, "[Duplic] Entity pasted")
return

end

local ent = tr.m_pEnt
if not IsValidEnt(ent) then return end

local phys = ent:VPhysicsGetObject()

self.Dups = {
class  = ent:GetClassname(),
model  = ent.GetModelName and ent:GetModelName() or nil,
angles = ent:GetAbsAngles(),
mass   = phys ~= NULL and phys:GetMass() or nil
}

draw:Con_NPrintf(2, "[Duplic] Entity copied safely")
end

self:RegisterTool(TOOL.Name, TOOL)
end

do
local TOOL = NewTool("igniter", "Igniter", "Ignite entities")

function TOOL:PrimaryAttack(swep, pPlayer, tr)  
  if tr:DidHitWorld() then return end  
  local ent = tr.m_pEnt  
  if not ent or ent == NULL or ent:IsPlayer() then return end  
  if ent.Ignite then ent:Ignite(30) else engine.ServerCommand("ent_fire !picker ignite\n")  
  end  
end  

self:RegisterTool(TOOL.Name, TOOL)

end

do
local TOOL = NewTool("extinguisher", "Extinguisher", "Extinguish fire")

function TOOL:PrimaryAttack(swep, pPlayer, tr)  
  if tr:DidHitWorld() then return end  
  local ent = tr.m_pEnt  
  if not ent or ent == NULL then return end  
  if ent.Extinguish then ent:Extinguish() end  
end  

self:RegisterTool(TOOL.Name, TOOL)

end

do
local TOOL = NewTool("eraser", "Entity Eraser", "Remove entities")

function TOOL:PrimaryAttack(swep, pPlayer, tr)  
  if tr:DidHitWorld() then return end  
  local ent = tr.m_pEnt  
  if not ent or ent == NULL or ent:IsPlayer() then return end  
  if ent.Remove then ent:Remove() else engine.ServerCommand("ent_remove " .. ent:entindex()) end  
end  

self:RegisterTool(TOOL.Name, TOOL)

end

do
local TOOL = NewTool("glow", "Glow Orb", "Spawn glowing melon")

function TOOL:PrimaryAttack(swep, pPlayer, tr)  
  local pos = tr.endpos  
  if not pos then return end  

  local melon = CreateEntityByName("prop_physics")  
  melon:SetModel(MELON_MODEL)  
  melon:SetAbsOrigin(pos)  
  melon:Spawn()  
  melon:Activate()  

  local light = CreateEntityByName("light_dynamic")  
  light:SetAbsOrigin(pos)  
  light:KeyValue("brightness", "10")  
  light:KeyValue("distance", "200")  
  light:KeyValue("_light", "100 200 255 255")  
  light:SetParent(melon, 0)  
  light:Spawn()  
  light:Activate()  
end  

self:RegisterTool(TOOL.Name, TOOL)

end

do
local TOOL = NewTool("rewind", "Rewind", "Manipulate time")

TOOL.History = {}
TOOL.MaxTicks = 300

local function IsValidEnt(ent)
    return ent and ent ~= NULL and not ent:IsPlayer()
end

local function Capture(ent)
    return {
        pos = ent:GetAbsOrigin(),
        ang = ent:GetAbsAngles(),
        health = ent.health or 0
    }
end

local function Apply(ent, snap)
    if not snap then return end
    ent:SetAbsOrigin(snap.pos)
    ent:SetAbsAngles(snap.ang)
end

function TOOL:Record(ent)
    local id = ent:entindex()
    self.History[id] = self.History[id] or {}

    table.insert(self.History[id], Capture(ent))

    if #self.History[id] > self.MaxTicks then
        table.remove(self.History[id], 1)
    end
end

function TOOL:PrimaryAttack(swep, pPlayer, tr)
    local ent = tr.m_pEnt
    if not IsValidEnt(ent) then return end

    local id = ent:entindex()
    if not self.History[id] then
        draw:Con_NPrintf(2, "[Rewind] No history")
        return
    end

    for i = #self.History[id], 1, -1 do
        Apply(ent, self.History[id][i])
    end

    draw:Con_NPrintf(2, "[Rewind] Time reversed")
end

function TOOL:SecondaryAttack(swep, pPlayer, tr)
    local ent = tr.m_pEnt
    if not IsValidEnt(ent) then return end

    local id = ent:entindex()
    local history = self.History[id]
    if not history then
        draw:Con_NPrintf(2, "[Rewind] No history for ghost")
        return
    end

    local clone = CreateEntityByName(ent:GetClassname())
    if not clone or clone == NULL then return end

    clone:SetModel(ent:GetModelName())
    clone:SetAbsOrigin(ent:GetAbsOrigin())
    clone:SetAbsAngles(ent:GetAbsAngles())
    clone:Spawn()
    clone:Activate()

    local tick = 1

    clone.Think = function(selfClone)
        if tick <= #history then
            Apply(selfClone, history[tick])
            tick = tick + 1
        end
    end

    draw:Con_NPrintf(2, "[Rewind] Ghost created")
end

hook.Add("PlayerThink", "RewindRecorder", function()
    for id, hist in pairs(TOOL.History) do
        local ent = Entity(id)
        if IsValidEnt(ent) then
            TOOL:Record(ent)
        end
    end
end)

self:RegisterTool(TOOL.Name, TOOL)

end

for k in pairs(self.Tools) do
self.CurrentTool = k
break
end

print("[Toolgun] Tools loaded: " .. tostring(table.Count(self.Tools)))
end

function SWEP:GetDrawActivity()
return ACT.VM_DRAW
end

function SWEP:Holster(pSwitchingTo)
end

function SWEP:ItemPostFrame()
local draw = MoveHelper()
draw:Con_NPrintf(3, "[TOOLGUN]")
draw:Con_NPrintf(4, "Active Tool: " .. tostring(self.CurrentTool))
draw:Con_NPrintf(5, "Tools Loaded: " .. tostring(table.Count(self.Tools)))
end

function SWEP:ItemBusyFrame()
end

function SWEP:DoImpactEffect()
end