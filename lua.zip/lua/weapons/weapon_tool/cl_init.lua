include("shared.lua")

if CLIENT then

local texid = nil

function SWEP:DrawLargeWeaponBox(bSelected, xpos, ypos, boxWide, boxTall, selectedColor, alpha, number)

    if not texid then
        texid = surface.CreateNewTextureID()
    end

    surface.DrawSetColor(255, 255, 255, 255)
    surface.DrawFilledRect(xpos, ypos, boxWide, boxTall)

    surface.DrawSetTexture(texid)
    surface.DrawSetColor(255, 255, 255, 255)
    surface.DrawTexturedRect(
        xpos + 4,
        ypos + 4,
        boxWide - 8,
        boxTall - 8
    )

    surface.DrawSetTextColor(255, 255, 255, 255)
    surface.DrawSetTextPos(xpos + 6, ypos + 2)
    surface.DrawPrintText("§")

end

end

function SWEP:DrawModel( flags )
end

function SWEP:MuzzleFlash( pos1, angles, type, firstPerson )
end