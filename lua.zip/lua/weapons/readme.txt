Always use this when making a SWEP:


SWEP.__base = "weapon_hl2mpbase_scriptedweapon"

or

SWEP.__base = "weapon_tabledbase_scriptedweapon"

Always put this at the top of the code, 
otherwise SWEP will throw an error at your face