--- Copyright © 2026, YourLocalCappy, all rights deserved ---

cbasepanel = cbasepanel or {}

require("vgui")

local BASE = {}

function BASE.Init(self)
	self.Visible = true
	self.Enabled = true
	self.Children = {}

	self.Hovered = false
	self.Depressed = false
end

function BASE.SetPos(self, x, y)
   if self:SetPosition then
	self:SetPosition(x, y)
   end
end

function BASE.SetSize(self, w, h)
   if self:SetWide and self:SetTall then
	self:SetWide(w)
	self:SetTall(h)
   end
end

function BASE.SetVisible(self, b)
	self.Visible = b

   if self:SetPaintedManually then
	self:SetPaintedManually(not b)
   end
end

function BASE.Add(self, child)
	child:SetParent(self)
	self.Children[#self.Children + 1] = child
	return child
end

function BASE.Think(self)
	local mx, my = input.GetCursorPos()
	local x, y = self:LocalToScreen(0, 0)
	local w, h = self:GetWide(), self:GetTall()

	self.Hovered =
		mx >= x and my >= y and
		mx <= x + w and
		my <= y + h
end

function BASE.OnMousePressed(self, code)
	self.Depressed = true
end

function BASE.OnMouseReleased(self, code)
	self.Depressed = false
end

function BASE.Paint(self, w, h)
	if not self.Visible then return end

	surface.DrawSetColor(45, 45, 45, 220)
	surface.DrawRect(0, 0, w, h)

	if self.Hovered then
		surface.DrawSetColor(255, 255, 255, 10)
		surface.DrawRect(0, 0, w, h)
	end
end

local function applyBase(panel)
	for k, v in pairs(BASE) do
		panel[k] = v
	end

	panel:Init()
	return panel
end

function cbasepanel.CreatePanel(parent)
	local pnl = vgui.Panel()
	if parent then pnl:SetParent(parent) end
	return applyBase(pnl)
end

function cbasepanel.CreateButton(parent)
	local btn = vgui.Button()
	if parent then btn:SetParent(parent) end
	return applyBase(btn)
end

function cbasepanel.CreateCheckButton(parent)
	local chk = vgui.CheckButton()
	if parent then chk:SetParent(parent) end
	return applyBase(chk)
end

function cbasepanel.CreateFrame(parent)
	local frm = vgui.Frame()
	if parent then frm:SetParent(parent) end
	return applyBase(frm)
end

if not concommand then
  concommand = require("concommand")
end

function concommand.Add(name, fn)
  concommand.Create(name, fn, "None", 0)
end

function OnPanelTest()
  local frame = cbasepanel.CreateFrame()
  frame:SetSize(400, 300)
  frame:SetVisible(true)
  frame:SetPaintedManually(false)

  local btn = cbasepanel.CreateButton(frame)
  btn:SetSize(120, 30)

  function btn:DoClick()
    print("click")
  end
end

concommand.Add("TestCPanel", OnPanelTest)