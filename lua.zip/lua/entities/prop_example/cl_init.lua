
include( "shared.lua" )

function ENT:DrawModel( flags )
end

function ENT:ClientThink()
end
