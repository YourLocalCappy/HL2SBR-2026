
include( "shared.lua" )

function ENT:Think()
end
