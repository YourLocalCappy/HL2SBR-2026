--- Copyright � 2026, YourLocalCappy, all rights deserved ---

ENT.__base = "trigger_scripted"
ENT.__factory = "CBaseTrigger"

function ENT:Initialize()
end

function ENT:PassesTriggerFilters( pOther )
end

function ENT:Think( pOther )
end

function ENT:StartTouch( pOther )
end

function ENT:Touch( pOther )
end

function ENT:EndTouch( pOther )
end
