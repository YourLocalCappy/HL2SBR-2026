--- Copyright � 2026, YourLocalCappy, all rights deserved ---

ENT.__base = "prop_scripted"
ENT.__factory = "CBaseAnimating"

function ENT:Initialize()
end

function ENT:StartTouch( pOther )
end

function ENT:Touch( pOther )
end

function ENT:EndTouch( pOther )
end

function ENT:VPhysicsUpdate( pPhysics )
end
